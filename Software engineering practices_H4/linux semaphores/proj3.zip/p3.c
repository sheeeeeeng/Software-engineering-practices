#include <stdio.h>
#include "awk_sem.h"

main() {
    int i = 0 ;
    // *** please insert proper semaphore initialization here
    do {
        // *** this is where you should place semaphore 
       
       printf("P3333333 is here\n"); i++ ;
       
       // *** this is where you should place semaphore
   
    }  while (i< 200);
}